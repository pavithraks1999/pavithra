from django.apps import AppConfig


class ReferalSiteConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "referal_site"
